// do something!

import { Nav, NewsList } from './components/index.js';



Nav();

NewsList();
