import AnalogClock from './AnalogClock.js';

//const a = document.querySelectorAll('.analog-clock');

document.querySelectorAll('.analog-clock').forEach(AnalogClock);
